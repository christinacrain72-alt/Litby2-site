import React from 'react'
export default function App() {
  return <h1 className="text-pink-600 text-3xl font-bold p-6">Lit by 2 Website is working!</h1>
}
